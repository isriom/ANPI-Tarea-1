///////////////////////////////////////////////////////////////
//  Copyright 2011 John Maddock. Distributed under the Boost
//  Software License, Version 1.0. (See accompanying file
//  LICENSE_1_0.txt or copy at https://www.boost.org/LICENSE_1_0.txt

#include "sf_performance.hpp"

void basic_tests()
{
   basic_tests_1();
   basic_tests_2();
   basic_tests_3();
   basic_tests_4();
   basic_tests_5();
   basic_tests_6();
   basic_tests_7();
   basic_tests_8();
   basic_tests_9();
}
